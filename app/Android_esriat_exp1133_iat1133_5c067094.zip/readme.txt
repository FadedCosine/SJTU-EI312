1.使用demo测试时，需将res中资源拷贝到demo中assets相应的路径下;
2.使用带UI接口时，请将assets下文件拷贝到项目中;
3.文档说明请参考:http://doc.xfyun.cn/msc_android/

感谢您使用科大讯飞服务。
官方网站：http://www.xfyun.cn/
